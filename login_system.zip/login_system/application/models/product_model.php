<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Product_model extends CI_Model
{
	function getProduct()
	{
		$this->db->order_by('product_id','desc');
		$query = $this->db->get('info');
		if($query->num_rows() > 0)
		{
			return $query->result();
		}
		else
		{
			return false;
		}
	}
	function insert($field)
	{
		$query = $this->db->insert('info',$field);
		if($this->db->affected_rows() > 0)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	function getProductId($id)
	{
		$this->db->where('product_id',$id);
		$query = $this->db->get('info');
		if($query->num_rows() > 0)
		{
			return $query->row();
		}
		else
		{
			return false;
		}
	}
	function update($id,$field)
	{
		$this->db->where('product_id',$id);
		$query = $this->db->update('info',$field);
		if($this->db->affected_rows() > 0)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	function delete($id)
	{
		$this->db->where('product_id',$id);
		$query = $this->db->delete('info');
		if($this->db->affected_rows() > 0)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	function fetch_data($query)
	{
	  	$this->db->select("*");
	  	$this->db->from("info");
	  	if($query != '')
	  	{
	   		$this->db->like('product_name', $query);
	   		$this->db->or_like('product_category', $query);
	   		$this->db->or_like('product_price', $query);
	   		$this->db->or_like('product_description', $query);
	   		$this->db->or_like('product_quality', $query);
	  	}
	  	$this->db->order_by('product_id', 'DESC');
	  	return $this->db->get();
	}
}
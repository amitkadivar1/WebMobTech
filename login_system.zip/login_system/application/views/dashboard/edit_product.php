<h3>Edit Products</h3>
		<a href="<?php echo base_url('dashboard/index'); ?>" class="btn btn-default">Back</a>
		<br><br>
		<form action="<?php echo base_url('dashboard/update'); ?>" method="post" class="form-horizontal">
			<input type="hidden" name="txt_hidden" value="<?php echo $product->product_id; ?>">
			<div class="form-group">
				<label for="title" class="col-md-2 text-right">Product Name</label>
				<div class="col-md-10">
					<input type="text" name="txt_product_name" value="<?php echo 
					$product->product_name; ?>" class="form-control" required>
				</div>
			</div>
			
			<div class="form-group">
				<label for="category" class="col-md-2 text-right">Product Category
				</label>
				<div class="col-md-10">
					<select name="txt_product_category" class="form-control">
						<option value="Accessories"
						<?php
						if($product->product_category == 'Accessories')
						{
							echo "selected";
						}
						?>
						>Accessories</option>

						<option value="Kids"
						<?php
						if($product->product_category == 'Kids')
						{	
							echo "selected";
						}
						?>
						>Kids</option>

						<option value="Cloths"
						<?php
						if($product->product_category == 'Cloths')
						{
							echo "selected";
						}
						?>
						>Cloths</option>

						<option value="Electronics"
						<?php
						if($product->product_category == 'Electronics')
						{
							echo "selected";
						}
						?>
						>Electronics</option>
					
					</select>
				</div>
			</div>

			<div class="form-group">
				<label for="price" class="col-md-2 text-right">Product Price</label>
				<div class="col-md-10">
					<input type="text" name="txt_product_price" class="form-control" value="<?php echo $product->product_price ?>" required>
				</div>
			</div>

			<div class="form-group">
				<label for="description" class="col-md-2 text-right">Product Description</label>
				<div class="col-md-10">
					<textarea name="txt_product_description" class="form-control"><?php echo $product->product_description ?></textarea>
				</div>
			</div>

			<div class="form-group">
				<label for="quality" class="col-md-2 text-right">Product Quality</label>
				<div class="col-md-10">
					<input type="text" name="txt_product_quality" class="form-control" value="<?php echo $product->product_quality ?>">
				</div>
			</div>

			<div class="form-group">
				<label class="col-md-2 text-right"></label>
				<div class="col-md-10">
					<input type="submit" name="btnSave" class="btn btn-primary" value="Update">
				</div>
			</div>
		</form>

	
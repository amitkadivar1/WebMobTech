<h3>Product List</h3>
<?php
		if($this->session->flashdata('success_msg'))
		{
		?>
			<div class="alert alert-success">
				<a href="" class="close" data-dismiss="alert" aria-label="close">
				&times;</a>
				<?php echo $this->session->flashdata('success_msg'); ?>
			</div>
		<?php
		}
		?>
		<?php
		if($this->session->flashdata('error_msg'))
		{
		?>
			<div class="alert alert-danger">
				<a href="" class="close" data-dismiss="alert" aria-label="close">
				&times;</a>
				<?php echo $this->session->flashdata('error_msg'); ?>
			</div>
		<?php
		}
		?>
<a href="<?php echo base_url('dashboard/add'); ?>" class="btn btn-primary">Add New Product</a>
<a href="<?php echo base_url('search'); ?>" class="btn btn-success" style="float: right;">Search Products</a>
<br>
<br>
		<table class="table table-bordered table-responsive">
			<thead>
				<tr>
					<th>Product Id</th>
					<th>Product Name</th>
					<th>Product Category</th>
					<th>Product Price</th>
					<th>Product description</th>
					<th>Product Quality</th>
					<th>Action</th>
				</tr>
			</thead>
			<tbody>
				<div id="get_product"></div>
				<?php
					if($product)
					{
						foreach($product as $products)
						{
				?>
			<tr>
					<td><?php echo $products->product_id; ?></td>
					<td><?php echo $products->product_name; ?></td>
					<td><?php echo $products->product_category; ?></td>
					<td><?php echo $products->product_price; ?></td>
					<td><?php echo $products->product_description; ?></td>
					<td><?php echo $products->product_quality; ?></td>
					<td>
						<a href="<?php echo base_url('dashboard/edit/'.$products->product_id); ?>" class="btn btn-info">Edit</a>
						<a href="<?php echo base_url('dashboard/delete/'.$products->product_id); ?>" class="btn btn-danger" onclick="return confirm('Are You Sure You Want To Delete!!');">Delete</a>
					</td>
			</tr>
				<?php
						}
					}
				?>
		</tbody>
	</table>
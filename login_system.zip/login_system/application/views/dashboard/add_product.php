<h3>Add Products</h3>
		<a href="<?php echo base_url('dashboard/index'); ?>" class="btn btn-default">Back</a>
		<br><br>
		<form action="<?php echo base_url('dashboard/submit'); ?>" method="post" class="form-horizontal">
			<div class="form-group">
				<label for="title" class="col-md-2 text-right">Product Name</label>
				<div class="col-md-10">
					<input type="text" name="txt_product_name" class="form-control" required>
				</div>
			</div>
			
			<div class="form-group">
				<label for="category" class="col-md-2 text-right">Product Category
				</label>
				<div class="col-md-10">
					<select name="txt_product_category" class="form-control">
						<option value="Accessories">Accessories</option>
						<option value="Kids">Kidss</option>
						<option value="Cloths">Cloths</option>
						<option value="Electronics">Electronics</option>
					</select>
				</div>
			</div>

			<div class="form-group">
				<label for="price" class="col-md-2 text-right">Product Price</label>
				<div class="col-md-10">
					<input type="text" name="txt_product_price" class="form-control" required>
				</div>
			</div>

			<div class="form-group">
				<label for="description" class="col-md-2 text-right">Product Description</label>
				<div class="col-md-10">
					<textarea name="txt_product_description" class="form-control" required></textarea>
				</div>
			</div>

			<div class="form-group">
				<label for="quality" class="col-md-2 text-right">Product Quality</label>
				<div class="col-md-10">
					<input type="text" name="txt_product_quality" class="form-control" required>
				</div>
			</div>

			<div class="form-group">
				<label class="col-md-2 text-right"></label>
				<div class="col-md-10">
					<input type="submit" name="btnSave" class="btn btn-primary" value="Submit">
				</div>
			</div>
		</form>

	
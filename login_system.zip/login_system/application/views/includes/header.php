<!DOCTYPE html>
<html>
<head>
    <title>Product Inventory System</title>
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/bootstrap.min.css'); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/bootstrap-theme.min.css'); ?>">
    <script type="text/javascript" src="<?php echo base_url('assets/js/jquery2.js'); ?>"></script>
    <script type="text/javascript" src="<?php echo base_url('assets/js/bootstrap.min.js') ?>"></script>
    <script type="text/javascript" src="<?php echo base_url('assets/js/custom.js') ?>"></script>
</head>
<body>
    <div class="navbar navbar-default">
        <div class="container">
            <div class="navbar-header">
                <h2><span class="glyphicon glyphicon-home"></span>&nbsp;&nbsp;Product Inventory System</h2>
            </div>
            <ul style="padding-top: 15px; " class="nav navbar-nav navbar-right">
                <li><a href="<?php echo base_url('/auth/logout/') ?>"><span class="glyphicon glyphicon-log-out"></span>&nbsp;Logout</a></li>
            </ul>
        </div>
    </div>
    <div class="container">
            
    
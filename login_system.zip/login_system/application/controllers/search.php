<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

Class Search extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
		$this->load->model('product_model');
	}
	function index()
	{
		$this->load->view('dashboard/search');
	}
	function fetch()
	{
		$output = '';
		$query = '';
		
		if($this->input->post('query'))
		{
		  $query = $this->input->post('query');
		}
		$data = $this->product_model->fetch_data($query);
		$output .= '
		  <div class="table-responsive">
		     <table class="table table-bordered table-striped">
		      <tr>
		       <th>Product Name</th>
		       <th>Product Category</th>
		       <th>Product Price</th>
		       <th>Product Desciption</th>
		       <th>Product Quality</th>
		      </tr>
		  ';
		if($data->num_rows() > 0)
		{
		  foreach($data->result() as $row)
		  {
		   	$output .= '
		      <tr>
		       <td>'.$row->product_name.'</td>
		       <td>'.$row->product_category.'</td>
		       <td>'.$row->product_price.'</td>
		       <td>'.$row->product_description.'</td>
		       <td>'.$row->product_quality.'</td>
		      </tr>
		    ';
		  }
		}
		else
		{
		    $output .= '<tr>
		       <td colspan="5" align="center">No Data Found</td>
		       </tr>';
		}
		  $output .= '</table>';
		  echo $output;
	}
		 
}
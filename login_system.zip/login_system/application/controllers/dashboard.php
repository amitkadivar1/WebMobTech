<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

Class Dashboard extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->helper('url');
		$this->load->library('tank_auth');

		if (!$this->tank_auth->is_logged_in()) {
            redirect('/auth/login/');
        }
	}
	public function index()
	{
		$data["extra_js"] = array();
		$data['page_title'] = "Dasborad";
		$data['product'] = $this->product_model->getProduct();
		$data['main_content'] = 'dashboard/product';
		$this->load->view('main_content',$data);
	}
	public function add()
	{
		$this->load->view('includes/header');
		$this->load->view('dashboard/add_product');
		$this->load->view('includes/footer');	
	}
	public function submit()
	{
		$field = array(
			'product_name' => $this->input->post('txt_product_name'),
			'product_category' => $this->input->post('txt_product_category'),
			'product_price' => $this->input->post('txt_product_price'),
			'product_description' => $this->input->post('txt_product_description'),
			'product_quality' => $this->input->post('txt_product_quality')
		);
		$result = $this->product_model->insert($field);
		if($result)
		{
			$this->session->set_flashdata('success_msg','Your Product Successfully Added');
		}
		else
		{
			$this->session->set_flashdata('error_msg','Your Product Is Not Added');	
		}
		redirect(base_url('dashboard/index'));
	}
	public function edit($id)
	{
		$data['product'] = $this->product_model->getProductId($id);
		$this->load->view('includes/header');
		$this->load->view('dashboard/edit_product',$data);
		$this->load->view('includes/footer');	
	}
	public function update()
	{
		$id = $this->input->post('txt_hidden');
		$field = array(
			'product_name' => $this->input->post('txt_product_name'),
			'product_category' => $this->input->post('txt_product_category'),
			'product_price' => $this->input->post('txt_product_price'),
			'product_description' => $this->input->post('txt_product_description'),
			'product_quality' => $this->input->post('txt_product_quality')
		);
		$result = $this->product_model->update($id,$field);
		if($result)
		{
			$this->session->set_flashdata('success_msg','Your Product Successfully Updated');
		}
		else
		{
			$this->session->set_flashdata('error_msg','Your Product Is Not Updated');
		}
		redirect(base_url('dashboard'));
	}
	public function delete($id)
	{
		$result = $this->product_model->delete($id);
		if($result)
		{
			$this->session->set_flashdata('success_msg','Your Product Successfully Deleted');
		}
		else
		{
			$this->session->set_flashdata('error_msg','Your Product Not Deleted');	
		}
		redirect(base_url('dashboard'));	
	}
	
}